VOLTTRIN — PROJETO ANDROID NATIVO (GRADLE)

Este pacote foi preparado para abrir/compilar como projeto Gradle Android.
A pasta raiz contém settings.gradle e build.gradle e o módulo app/ contém
AndroidManifest.xml e o código Android. Não precisa executar npm install,
npx cap add android ou npx cap sync.

COMO COMPILAR NO ANDROIDFORGE
1. Extraia o ZIP.
2. Importe/abra a pasta Volttrin_Android_Gradle (a pasta que contém settings.gradle).
3. Se o AndroidForge pedir o módulo, selecione :app.
4. Execute a tarefa assembleDebug.
5. O APK de depuração normalmente fica em:
   app/build/outputs/apk/debug/app-debug.apk

DETALHES
- O aplicativo abre a versão web Volttrin dentro de uma WebView Android.
- JavaScript e armazenamento local estão habilitados para manter as funções e os dados locais.
- Tailwind, Font Awesome, fontes, PDF.js e QRCode são carregados por CDN; esses recursos
  precisam de internet.
- Este pacote contém o projeto-fonte Gradle, não um APK já compilado.
- Compatibilidade esperada: JDK 17, Android SDK 35 e Gradle 8.9 ou compatível com
  Android Gradle Plugin 8.7.3.
