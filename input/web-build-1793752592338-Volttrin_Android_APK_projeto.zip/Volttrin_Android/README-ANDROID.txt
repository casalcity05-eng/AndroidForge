VOLTTRIN — PROJETO PREPARADO PARA APK ANDROID
============================================

O QUE ESTÁ NESTA PASTA
- www/index.html: versão otimizada do aplicativo Volttrin.
- package.json: dependências do Capacitor para gerar o projeto Android.
- capacitor.config.json: nome, identificador e pasta de arquivos do app.

IMPORTANTE
Este pacote é o PROJETO-FONTE para compilar o APK. O APK ainda precisa ser
construído com Android SDK/Gradle em um computador ou serviço de build.
Não é o arquivo APK instalável.

COMO GERAR O APK NO WINDOWS
1. Instale Node.js LTS e Android Studio.
2. Extraia esta pasta.
3. Abra o terminal dentro da pasta Volttrin_Android.
4. Execute:

   npm install
   npx cap add android
   npx cap sync android
   npx cap open android

5. No Android Studio, aguarde a sincronização do Gradle.
6. Para gerar APK de teste: Build > Build Bundle(s) / APK(s) > Build APK(s).
7. O Android Studio mostrará a localização do APK gerado.

PARA ATUALIZAR O HTML NO FUTURO
Substitua www/index.html pelo novo HTML e execute:

   npx cap sync android

Depois gere o APK novamente no Android Studio.

OBSERVAÇÕES IMPORTANTES
- A interface e o catálogo presentes no HTML foram mantidos.
- As bibliotecas externas atuais (Tailwind, Font Awesome, Google Fonts,
  PDF.js e QRCode) continuam sendo carregadas pela internet. Para uso
  totalmente offline, será necessário empacotá-las localmente em uma etapa
  posterior, sem mudar a aparência ou os recursos.
- Os dados salvos no navegador podem não aparecer automaticamente na
  instalação Android, pois o WebView do app usa armazenamento separado.
  Faça backup/exportação dos dados antes de migrar. Não desinstale nem apague
  os dados da versão antiga até confirmar a migração.
- O identificador Android definido é br.com.volttrin.app. Evite alterá-lo
  depois de distribuir o aplicativo, pois ele identifica o app instalado.
