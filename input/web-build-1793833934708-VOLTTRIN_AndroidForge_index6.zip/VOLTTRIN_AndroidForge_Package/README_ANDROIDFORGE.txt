VOLTTRIN - Projeto AndroidForge

ARQUIVO HTML
- app/src/main/assets/index.html
- Copiado byte a byte do arquivo enviado index-6.html.
- Tamanho: 214958 bytes
- SHA-256: d124596ec93ef3650c02a162211a5f3497fafbf8878cee5fb65370d71a33b301

COMPILACAO
1. Abra/importa a pasta VOLTTRIN_AndroidForge_Package no AndroidForge.
2. Use JDK 17.
3. Execute a tarefa Gradle :app:assembleDebug.
4. O APK debug normalmente sera gerado em app/build/outputs/apk/debug/app-debug.apk.

CONFIGURACAO
- Namespace/Application ID: com.volttrin.app
- compileSdk: 35
- minSdk: 23
- targetSdk: 35
- Android Gradle Plugin: 8.7.3

OBSERVACOES
- O projeto inclui uma Activity Android com WebView e JavaScript habilitado.
- O HTML original nao foi editado.
- Bibliotecas CDN usadas pelo HTML dependem de conexao com a internet.
- Este pacote e a estrutura-fonte; o APK ainda precisa ser compilado no AndroidForge.
