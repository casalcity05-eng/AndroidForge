# VOLTTRIN para Android

Este projeto empacota o `index.html` original em um aplicativo Android usando WebView.
O arquivo HTML foi copiado sem edições para `app/src/main/assets/index.html`.

## Gerar o APK

1. Instale/abra o Android Studio em um computador.
2. Escolha **Open** e selecione a pasta `VolttrinAndroid`.
3. Aguarde a sincronização do Gradle e a instalação do Android SDK 35, se solicitado.
4. Selecione **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. O APK de depuração será criado em `app/build/outputs/apk/debug/app-debug.apk`.

## Observações

- O aplicativo mantém a interface e a lógica do HTML original; a camada Android apenas hospeda a página.
- Tailwind, Font Awesome, Google Fonts, PDF.js e QRCode.js são carregados pelas URLs CDN que já existem no HTML. Portanto, a primeira utilização desses recursos exige conexão com a internet.
- Dados de projetos, clientes e estoque continuam no `localStorage` do WebView deste aparelho. Não há sincronização em nuvem configurada no HTML fornecido.
- Este ambiente de criação não possui Android SDK/Gradle instalados, então foi possível preparar o projeto Android, mas não compilar/testar um APK aqui.
