VOLTTRIN - PROJETO ANDROID PARA ANDROIDFORGE

ESTRUTURA DO PROJETO
- settings.gradle: arquivo de configuração da raiz e inclusão do módulo :app.
- build.gradle: configuração raiz do plugin Android Gradle.
- gradle.properties: propriedades gerais do Gradle.
- app/build.gradle: configuração do módulo Android.
- app/src/main/AndroidManifest.xml: manifesto e permissão de internet.
- app/src/main/java/com/volttrin/app/MainActivity.java: contêiner Android WebView.
- app/src/main/assets/index.html: código-fonte web VOLTTRIN original.

IMPORTAÇÃO
1. Extraia o ZIP.
2. Importe no AndroidForge a pasta VOLTTRIN_AndroidForge (a pasta que contém settings.gradle), ou envie o ZIP mantendo os arquivos de configuração diretamente na raiz do projeto.
3. Selecione a tarefa Gradle :app:assembleDebug para gerar o APK de teste.
4. O projeto usa Android Gradle Plugin 8.7.3, Gradle 8.9 e JDK 17. Requer SDK Android 35 instalado no ambiente de compilação.

IMPORTANTE
- O index.html foi copiado sem edição para app/src/main/assets/index.html.
- As bibliotecas Tailwind, Font Awesome, Google Fonts, PDF.js e QRCode continuam sendo carregadas pelos endereços CDN já presentes no HTML; por isso, o aplicativo precisa de conexão com a internet para esses recursos.
- O WebView habilita JavaScript, armazenamento DOM/localStorage e seletor de arquivos para o envio de PDF.
- Este pacote organiza a estrutura de compilação; não é um APK já compilado.
