# Minificação desativada para preservar o comportamento do WebView e do aplicativo.
