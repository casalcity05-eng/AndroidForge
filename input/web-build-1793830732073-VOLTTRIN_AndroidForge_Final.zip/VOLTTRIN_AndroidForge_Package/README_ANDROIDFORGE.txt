VOLTTRIN - Projeto Android para AndroidForge

Importe o ZIP pela pasta raiz que contém settings.gradle e build.gradle.
Não selecione a pasta app como raiz.

Tarefa Gradle sugerida: :app:assembleDebug
Android Gradle Plugin: 8.7.3
Gradle compatível: 8.9
JDK: 17
compileSdk: 35
minSdk: 23

O index.html fornecido foi copiado sem alterações para:
app/src/main/assets/index.html

A aplicação abre o HTML local em uma WebView com JavaScript, DOM Storage,
acesso à internet para recursos CDN e seletor de arquivos para PDFs.
A compilação final precisa ser executada no AndroidForge com Android SDK.
