package com.volttrin.app

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout

class MainActivity : Activity() {
    private lateinit var root: FrameLayout
    private lateinit var webView: WebView
    private var popup: WebView? = null
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private val fileRequestCode = 7401

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        root = FrameLayout(this)
        webView = createWebView()
        root.addView(webView, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)
        webView.loadUrl("file:///android_asset/index.html")
    }


    @Deprecated("Deprecated by Android")
    override fun onBackPressed() {
        val p = popup
        if (p != null) {
            root.removeView(p)
            p.destroy()
            popup = null
        } else if (webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }

    private fun createWebView(): WebView {
        return WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.databaseEnabled = true
            settings.allowFileAccess = true
            settings.allowContentAccess = true
            settings.javaScriptCanOpenWindowsAutomatically = true
            settings.setSupportMultipleWindows(true)
            settings.cacheMode = WebSettings.LOAD_DEFAULT
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                    val url = request.url
                    val scheme = url.scheme ?: return false
                    if (scheme == "file" || scheme == "about") return false
                    if (scheme == "http" || scheme == "https" || scheme == "whatsapp" || scheme == "tel" || scheme == "mailto") {
                        return try { startActivity(Intent(Intent.ACTION_VIEW, url)); true } catch (_: Exception) { false }
                    }
                    return false
                }
            }
            webChromeClient = object : WebChromeClient() {
                override fun onShowFileChooser(
                    webView: WebView,
                    filePathCallback: ValueCallback<Array<Uri>>,
                    fileChooserParams: FileChooserParams
                ): Boolean {
                    this@MainActivity.fileCallback?.onReceiveValue(null)
                    this@MainActivity.fileCallback = filePathCallback
                    val intent = fileChooserParams.createIntent()
                    return try { startActivityForResult(intent, fileRequestCode); true }
                    catch (_: Exception) { this@MainActivity.fileCallback = null; false }
                }

                override fun onCreateWindow(view: WebView, isDialog: Boolean, isUserGesture: Boolean, resultMsg: android.os.Message): Boolean {
                    popup?.let { root.removeView(it); it.destroy() }
                    val child = createPopupWebView()
                    popup = child
                    root.addView(child, FrameLayout.LayoutParams(-1, -1))
                    val transport = resultMsg.obj as WebView.WebViewTransport
                    transport.webView = child
                    resultMsg.sendToTarget()
                    return true
                }
            }
        }
    }

    private fun createPopupWebView(): WebView = WebView(this).apply {
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.allowFileAccess = true
        settings.javaScriptCanOpenWindowsAutomatically = true
        webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val url = request.url
                val scheme = url.scheme ?: return false
                if (scheme == "file" || scheme == "about") return false
                return try { startActivity(Intent(Intent.ACTION_VIEW, url)); true } catch (_: Exception) { false }
            }
        }
        webChromeClient = WebChromeClient()
    }

    @Deprecated("Deprecated by Android; retained for WebView file chooser compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == fileRequestCode) {
            val result = if (resultCode == RESULT_OK) WebChromeClient.FileChooserParams.parseResult(resultCode, data) else null
            fileCallback?.onReceiveValue(result)
            fileCallback = null
        }
    }

    override fun onDestroy() {
        popup?.destroy()
        webView.destroy()
        super.onDestroy()
    }
}
