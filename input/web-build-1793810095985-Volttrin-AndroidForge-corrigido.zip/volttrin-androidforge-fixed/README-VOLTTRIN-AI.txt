VOLTTRIN — MÓDULO ADITIVO DE LEITURA DE PROJETOS

Arquivos:
- index.html: aplicativo original com apenas um botão e uma janela nova dentro do projeto/orçamento. Os módulos, abas e funções existentes foram preservados.
- server.js / package.json / .env.example: backend opcional para análise por IA real (inclui PDF com leitura visual das páginas).

IMPORTANTE SOBRE A INTELIGÊNCIA:
O botão tenta primeiro chamar POST /api/volttrin/analisar-projeto no mesmo domínio. Para análise inteligente real, hospede server.js atrás do mesmo domínio/proxy da aplicação, configure OPENAI_API_KEY no ambiente do servidor e instale as dependências com `npm install`; depois execute `npm start`.
NUNCA coloque a chave da API no HTML ou no navegador.

Sem o backend conectado, o HTML oferece somente extração preliminar de texto PDF/DOCX e sugestões por palavras-chave. Isso NÃO lê desenhos escaneados nem substitui a análise visual por IA. A tela informa essa limitação.

O backend aceita PDF, DOCX, DOC, RTF, ODT e TXT (limite 50 MB). Para PDF, a API recebe o arquivo como input_file com detalhe visual alto, podendo analisar texto e imagens das páginas. Documentos Word são extraídos como texto pela API; imagens embutidas em DOCX podem não ser interpretadas. Para máxima fidelidade de plantas e diagramas, exporte o documento para PDF antes de enviar.

Após analisar, confira as quantidades, ajuste os itens, informe os preços unitários e salve o detalhamento no projeto. A geração de orçamento detalhado é separada do PDF antigo para não alterar o modelo já existente.

TESTES EXECUTADOS:
- JavaScript inline: verificação de sintaxe Node.
- Backend server.js: verificação de sintaxe Node.
- Comparação estrutural: mudanças limitadas ao botão novo, modal novo, bibliotecas de leitura de documentos e funções novas isoladas.
