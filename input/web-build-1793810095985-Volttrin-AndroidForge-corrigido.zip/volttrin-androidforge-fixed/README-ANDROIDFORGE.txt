VOLTTRIN - PACOTE ANDROID PARA ANDROIDFORGE

Este pacote adiciona somente a estrutura Android/Gradle necessária para o AndroidForge reconhecer e compilar o aplicativo web.
O arquivo HTML original foi copiado sem alterações para app/src/main/assets/index.html.

Como compilar:
1. Envie este ZIP no AndroidForge.
2. Selecione Android / build variant debug (ou auto).
3. Aguarde o workflow e baixe o artefato AndroidForge-APKs.

A aplicação é exibida em uma WebView Android. JavaScript, armazenamento local e seletor de arquivos estão habilitados.
O backend Node (backend-server.js e backend-package.json) é mantido como referência separada; ele precisa ser hospedado em um servidor HTTPS externo para habilitar a análise real por IA. Não coloque chaves de API no APK/HTML.
