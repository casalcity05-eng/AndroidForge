// Backend opcional da análise inteligente Volttrin.
// Mantém a chave OpenAI no servidor; nunca coloque OPENAI_API_KEY no index.html.
const express = require('express');
const multer = require('multer');
const OpenAI = require('openai');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

const app = express();
const upload = multer({ dest: path.join(__dirname, 'uploads'), limits: { fileSize: 50 * 1024 * 1024 } });
const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

app.post('/api/volttrin/analisar-projeto', upload.single('document'), async (req, res) => {
  let uploaded;
  try {
    if (!process.env.OPENAI_API_KEY) return res.status(503).json({ error: 'OPENAI_API_KEY não configurada no servidor.' });
    if (!req.file) return res.status(400).json({ error: 'Envie um PDF ou DOCX.' });
    const ext = path.extname(req.file.originalname).toLowerCase();
    const allowed = ['.pdf', '.docx', '.doc', '.rtf', '.odt', '.txt'];
    if (!allowed.includes(ext)) return res.status(415).json({ error: 'Formato não suportado.' });

    uploaded = await client.files.create({ file: fs.createReadStream(req.file.path), purpose: 'user_data' });
    const instructions = `Você é um orçamentista técnico de instalações elétricas residenciais. Analise o documento INTEIRO, todas as páginas e elementos visuais disponíveis. Extraia somente atividades de MÃO DE OBRA que precisam ser executadas. Não inclua compra/fornecimento de materiais como mão de obra. Separe cada atividade em uma linha específica (ex.: instalar lâmpada, instalar spot, instalar plafon, instalar trilho, passar cabo, instalar tomada, instalar interruptor, preparar ponto, instalar luminária, executar circuito). Não agrupe serviços diferentes. Use quantidades explícitas do documento; não invente quantidades. Se a quantidade não estiver explícita, use quantity=1 e review=true, deixando claro em source que precisa levantamento/conferência. Se houver divergência entre páginas/listas/desenhos, mantenha a quantidade mais conservadora e marque review=true explicando a divergência em source. Exclua serviços expressamente fora do escopo. Diferencie instalação, remoção, substituição e preparação quando forem trabalhos diferentes. Não dimensione cabos/disjuntores nem aprove tecnicamente o projeto. Retorne APENAS JSON válido neste formato: {"pages": número, "items":[{"description":"...","quantity":1,"unit":"un.|m|ponto|circuito|serviço","source":"referência de página/trecho e observação","review":true}]}. Nunca inclua preços.`;
    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || 'gpt-4.1',
      input: [{ role: 'user', content: [
        { type: 'input_file', file_id: uploaded.id, detail: ext === '.pdf' ? 'high' : undefined },
        { type: 'input_text', text: instructions }
      ] }]
    });
    let raw = (response.output_text || '').trim().replace(/^```(?:json)?\s*/i, '').replace(/```$/,'').trim();
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed.items)) throw new Error('A IA não retornou a lista de serviços esperada.');
    const items = parsed.items.map(x => ({
      description: String(x.description || 'Serviço a revisar').slice(0, 240),
      quantity: Number.isFinite(Number(x.quantity)) && Number(x.quantity) > 0 ? Number(x.quantity) : 1,
      unit: String(x.unit || 'serviço').slice(0, 24),
      source: String(x.source || '').slice(0, 500),
      review: x.review !== false
    }));
    res.json({ pages: Number(parsed.pages) || null, items });
  } catch (err) {
    console.error('Volttrin document analysis:', err);
    res.status(500).json({ error: 'Não foi possível concluir a análise inteligente deste documento.' });
  } finally {
    if (uploaded?.id) client.files.delete(uploaded.id).catch(()=>{});
    if (req.file?.path) fs.promises.unlink(req.file.path).catch(()=>{});
  }
});

const port = Number(process.env.PORT || 3000);
app.listen(port, () => console.log(`Volttrin AI backend ativo na porta ${port}`));
